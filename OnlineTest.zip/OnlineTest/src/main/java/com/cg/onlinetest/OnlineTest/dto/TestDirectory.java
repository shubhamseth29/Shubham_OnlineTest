package com.cg.onlinetest.OnlineTest.dto;

import java.util.LinkedHashMap;

public class TestDirectory 
{	
	
	public void testDirectory()
	{
		System.out.println();
		
	}
}
