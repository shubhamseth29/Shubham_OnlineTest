package com.cg.onlinetest.OnlineTest.services;
import com.cg.onlinetest.OnlineTest.dto.*;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Scanner;
public class adminServices {
	Scanner sc=new Scanner(System.in);
	LinkedHashMap<String,Test> allTests=new LinkedHashMap<String, Test>();
	
	public void addTest()
	{	
		System.out.println("Enter Test Title");
		String title=sc.nextLine();
		Test test=new Test(title);
		allTests.put(title, test);
		
		System.out.println("Do you want to add questions(Yes / No)");
		String ans=sc.nextLine();
		if(ans.equalsIgnoreCase("Yes"))
		{
			addQuestionFromTest(title);
		}
		else
			System.out.println("Okay Bye!");
	}
	
	public void updateTest()
	{
		
	}
	
	public void deleteTest()
	{
		
	}
	
	public void addQuestionFromTest(String title)
	{	
		System.out.println("How many questions do you want to add?");
		int num=sc.nextInt();
		ArrayList<Question> list1=new ArrayList<Question>();
		while(num>0)
		{
			System.out.println("Enter question id");
			BigInteger id=sc.nextBigInteger();
			sc.nextLine();
			System.out.println("Enter question");
			String str=sc.nextLine();
			System.out.println("Enter options:");
			int count=1;
			HashMap<Integer, String> options=new HashMap<Integer, String>();
			while (count<5)
			{
				System.out.println("Set option "+ count);
				String opt= sc.nextLine();
				options.put(count,opt);
				count++;
			}
			int correctAnswer;
			System.out.println("Enter correct answer(1/2/3/4)");
			correctAnswer=sc.nextInt();
			Question question=new Question(id, options, str, correctAnswer);
//			Test obj=allTests.get(title);
//			ArrayList<Question> list1=obj.getQuestionsList();
//			list1.add(question);
			
			list1.add(question);
			num--;
		}
		allTests.get(title).setQuestionList(list1);
	}
	public void addQuestion()
	{		
		System.out.println("Enter Test Title in which you want to add !");
		System.out.println(allTests.keySet());
		String title=sc.nextLine();
		System.out.println("How many questions do you want to add?");
		int num=sc.nextInt();
		while(num>0)
		{
			System.out.println("Enter question id");
			BigInteger id=sc.nextBigInteger();
			sc.nextLine();
			System.out.println("Enter question");
			String str=sc.nextLine();
			System.out.println("Enter options:");
			int count=1;
			HashMap<Integer, String> options=new HashMap<Integer, String>();
			while (count<5)
			{
				System.out.println("Set option "+ count);
				String opt= sc.nextLine();
				options.put(count,opt);
				count++;
			}
			int correctAnswer;
			System.out.println("Enter correct answer(1/2/3/4)");
			correctAnswer=sc.nextInt();
			Question question=new Question(id, options, str, correctAnswer);
			Test obj=allTests.get(title);
			ArrayList<Question> obj1=obj.getQuestionsList();
			obj1.add(question);
			num--;
		}
	}
	
	public void updateQuestion()
	{
		
	}
	
	public void deleteQuestion()
	{
		
	}

	
}
