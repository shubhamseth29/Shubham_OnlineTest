package com.cg.onlinetest.OnlineTest.exe;
import java.io.IOException;
import java.util.Scanner;
import com.cg.onlinetest.OnlineTest.dto.TestUser;
import com.cg.onlinetest.OnlineTest.dto.admin;

public class MainClass  
{
	
	public static void main(String[] args) throws ClassNotFoundException, IOException  {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("--------WELCOME TO ONLINE TEST PORTAL--------");
		System.out.println("Login as : ");
		System.out.println("1. ADMIN");
		System.out.println("2. USER");
		int x=sc.nextInt();
		if(x==1)
			new admin().login();
		else if(x==2)
			new TestUser().login();
		else
			System.out.println("Wrong Input (Enter 1 or 2)");
		
	}
	
}
