package com.cg.onlinetest.OnlineTest.dto;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class Question {
	
	BigInteger questionId;
	HashMap questionOptions;
	String questionTitle;
	Integer questionAnswer;
	Integer chosenAnswer;
	BigDecimal marksScored;
	
	public Question(BigInteger questionId,HashMap questionOptions,String questionTitle,Integer questionAnswer )
	{
		this.questionId=questionId;
		this.questionOptions=questionOptions;
		this.questionTitle=questionTitle;
		this.questionAnswer=questionAnswer;
		
	}
	
	

}
