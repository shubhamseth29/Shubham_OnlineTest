package com.cg.onlinetest.OnlineTest.dto;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Set;

public class Test {
	
	String testTitle;
	ArrayList<Question> questionList;
	
		
	public Test(String testTitle)
	{
		this.testTitle=testTitle;
		ArrayList<Question> questionList=new ArrayList<Question>();
	}
	
	public ArrayList<Question> getQuestionsList()
	{
		return questionList;
	}
	
	public void setQuestionList(ArrayList<Question> questionList)
	{
		this.questionList=questionList;
	}
	
	

}
